# React Shop Example No 4

Sergei Palaznik, 2021

Second version of my forth attempt at creating a store app, based on the Dennis Archakov stream "Shopping Cart".
The project was developed without CRA, with self-configuring webpack.
A fake server was also used (later replaced with Firebase).\
To use this version you need to unpack `settings-without-cra.zip` into the root folder and run the command `npm install`.

## Used teqnologies:
- ReactJS
- Redux
- lodash
- Semantic UI

## Available Scripts

### `npm run dev`
- Runs the app in the development mode.
Open http://localhost:3000 to view it in the browser.
The page will reload if you make edits. You will also see any lint errors in the console.
For correctly work of the build, need running fake json server as localhost.

### `npm run build`
- Builds the app for production to the build folder (./dist).
It correctly bundles React in production mode and optimizes the build for the best performance.
The build is minified and the filenames include the hashes. Your app is ready to be deployed!
For correctly work of the build, need running fake json server as localhost.

### `npm run server`
Runs a fake json-server for the app to correctly work as http://localhost:3001.

## Additionaly
To use the json-server, you need to replace in `./components/App.jsx` line 12:
`axios.get("https://react-bookshop-a7f59-default-rtdb.firebaseio.com/books.json")`
to:
`axios.get("http://localhost:3001/books")`