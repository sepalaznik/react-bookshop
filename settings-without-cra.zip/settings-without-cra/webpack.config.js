const HtmlWebpackPlugin = require('html-webpack-plugin');

module.exports = {
    mode: "development",
    entry: './src/index.js',
    resolve: {
        extensions: ['', '.js', '.jsx'],
    },
    module: {
        rules: [
            {
                test: /\.(js|jsx)$/,
                exclude: /nodeModules/,
                use: {
                    loader: 'babel-loader'
                }
            },
            {
                test: /\.css$/,
                use: ['style-loader', 'css-loader']
            },
            {
                test: /\.(png|jpg|jpeg)$/,
                use: ['file-loader']
            },
            {
                test: /\.(eot|woff|woff2|svg|ttf)([\?]?.*)$/,
                use: ['file-loader']
            },
            { 
                test: /\.(woff|woff2|eot|ttf|svg)$/,
                use: ['url-loader?limit=100000'] }
        ]
    },
    devServer: {
        port: 3000,
        watchContentBase: true,
        historyApiFallback: true,
        inline: true, 
        contentBase: "./public"
    },
    plugins: [new HtmlWebpackPlugin({ template: './public/index.html' })],
}
